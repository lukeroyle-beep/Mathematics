"""Verify witness tests by direct modular powers and public lifting equations."""
from argparse import ArgumentParser


def residue(length, position, modulus):
    return (7 * pow(10, length, modulus) - 18 * pow(10, position, modulus) - 25) % modulus


def representative(length):
    depth, period, position = 1, 6, 3
    while period <= length:
        modulus = 7 ** (depth + 1)
        lifts = [
            position + digit * period
            for digit in range(7)
            if residue(length, position + digit * period, modulus) == 0
        ]
        if len(lifts) != 1:
            raise ArithmeticError(f"Expected one modular lift at {length=}, {depth=}")
        position = lifts[0]
        depth += 1
        period *= 7
    return position


def count(begin, end):
    lengths = actual = passes = 0
    for length in range(begin | 1, end + 1, 2):
        digit_sum = 7 * length - 4
        if digit_sum % 5 == 0:
            continue
        lengths += 1
        position = representative(length)
        if position >= length:
            continue
        actual += 1
        if residue(length, position, 9 * digit_sum) == 0:
            print(f"Hit {length=} {position=}")
            passes += 1
    return lengths, actual, passes


def check_control(length, position, modulus, expected):
    if residue(length, position, modulus) != expected:
        raise ArithmeticError(f"Failure at {length=}, {position=}, {modulus=}")


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("begin", type=int)
    parser.add_argument("end", type=int)
    args = parser.parse_args()
    check_control(61, 57, 9 * 423, 0)
    check_control(365, 225, 9 * 2551, 0)
    check_control(365, 225, 343, 98)
    check_control(313, 51, 2187, 0)
    check_control(313, 51, 9 * 2187, 17496)
    print(count(args.begin, args.end))
