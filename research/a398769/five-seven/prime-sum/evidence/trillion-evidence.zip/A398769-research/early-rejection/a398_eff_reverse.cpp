#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <cstdint>
using N=uint64_t;
N power(N b,N n,N m){N c=1;for(;n;n/=2,b=__uint128_t(b)*b%m)if(n%2)c=__uint128_t(c)*b%m;return c;}
N p7(unsigned n){N p=1;while(n--)p*=7;return p;}
int main(int argc,char**argv){
 N start=strtoull(argv[1],nullptr,10),end=strtoull(argv[2],nullptr,10);
 for(unsigned k=2;k<=11;k++){
  N big=p7(k),q=big/7,period=6*(q/7),first=std::max(start,period+1),last=std::min(end,7*period-1);
  if(first>last)continue;
  N h=p7(k/2),period_h=6*(h/7);
  std::vector<N> low(h),inv(h),high(q/h);
  N z=1,w=1,ten_inv=power(10,period-1,q);
  for(N j=0;j<period_h;j++){low[z%h]=j;inv[z%h]=w;z=z*10%q;w=__uint128_t(w)*ten_inv%q;}
  N incr=z;
  z=1;
  for(N j=0;j<q/h;j++){high[(z-1)/h]=j;z=__uint128_t(z)*incr%q;}
  N val=1000%big,six=1000000%big,cnt=0,hits=0;
  for(N i=3;i<last;i+=6,val=val*six%big){
   N y=((18*val+25)%big)/7;if(y%7==0)continue;
   N c=y%h,unit=__uint128_t(y)*inv[c]%q;
   N l0=low[c]+period_h*high[(unit-1)/h];
   if(l0%2==0)continue;
   N min=std::max(first,i+1);
   N l=l0+(min>l0?(min-l0+period-1)/period*period:0);
   for(;l<=last;l+=period){
    N s=7*l-4;if(s%5==0)continue;
    cnt++;
    N m=9*s,v=power(10,i,m),u=power(10,l,m);
    if((7*u)%m==(18*v+25)%m){hits++;printf("HIT %lu %lu k=%u\n",l,i,k);fflush(stdout);}
   }
  }
  fprintf(stderr,"reverse k=%u [%lu,%lu] actual=%lu hits=%lu\n",k,first,last,cnt,hits);
 }
}
