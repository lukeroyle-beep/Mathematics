# Digit-sum implication through the last odd length of the eleventh band

Put T_k = 6·7^(k−1) and let K(L) be the first k for which T_k > L. The implication (E) says that, for odd L ≥ 5 with 5 not dividing S = 7L−4, no admissible position satisfies both 9S | F and 7^K(L) | F. The retained project certificate covers odd L from 5 through 9,999,999. The two programs here cover every odd L from 10,000,001 through 1,694,851,493 inclusive. The one-trillion valuation scan in the adjacent folder establishes a different statement.

For fixed L and k the depth-k congruence prescribes 10^i modulo 7^k as the unit (7·10^L−25)/18. Since 10 generates the unit group of order T_k, it prescribes a unique residue i modulo T_k. Reduction modulo 7 forces i = 3 mod 6. At k=K(L), only its least nonnegative representative can be an actual position. The forward checker precomputes the exponent modulo the order of 10 at depth 6 and recovers the missing digits with the linear term of the binomial expansion. The modulus in this extension has depth at most 11, so the square of a multiple of 7^6 vanishes there.

The reverse checker starts from each i = 3 mod 6 and inverts the length congruence. Divide the least residue of 18·10^i+25 modulo 7^k by seven. A nonunit quotient cannot equal 10^L modulo 7^(k−1). For unit quotients two cycle tables recover the unique residue of L modulo T_(k−1). The checker visits all its odd representatives in the stated interval with L>i. Both programs remove sums divisible by five and check F modulo 9S. They use distinct modular power implementations for that test. The integer products for the largest modulus 9S fit within the 128-bit multiplication or reduction used in the code.

| K | First odd L | Last odd L | Odd lengths | Five-free sums | Actual eligible positions | Full-sum passes |
|---:|---:|---:|---:|---:|---:|---:|
| 9 | 10,000,001 | 34,588,805 | 12,294,403 | 9,835,523 | 6,339,890 | 0 |
| 10 | 34,588,807 | 242,121,641 | 103,766,418 | 83,013,134 | 47,436,017 | 0 |
| 11 | 242,121,643 | 1,694,851,493 | 726,364,926 | 581,091,941 | 332,049,380 | 0 |

Use these exact bounds with both C++ programs. For supported command arguments the forward checker prints a line for every hit, if any, and per-band counts to standard error. The reverse checker explicitly prints per-band hit counts. The separate Python implementation tests endpoints by repeated sets of seven candidate lifts and includes full-sum positive and negative controls.

```sh
g++ -std=c++17 -O3 a398_eff_scan.cpp -o forward
g++ -std=c++17 -O3 a398_eff_reverse.cpp -o reverse
./forward 10000001 1694851493
./reverse 10000001 1694851493
python3 a398_eff_reference.py 1694850495 1694851493
```

The source hashes, interval counts and six short reference windows are in a398_eff_results.json. [Earlier finite implication](https://github.com/lukeroyle-beep/Mathematics/blob/37bd10a930d6dc7c9a7bcfd8db7588451dc26da2/research/a398769/five-seven/early-rejection/README.md).
