#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
using U=unsigned long long;
using W=__uint128_t;
U powm(U a,U k,U m){U v=1;while(k){if(k&1)v=(W)v*a%m;a=(W)a*a%m;k>>=1;}return v;}
U pow7(int k){U p=1;while(k--)p*=7;return p;}
struct Mont{
 U m,inv;
 Mont(U x):m(x),inv(1){for(int k=0;k<6;k++)inv*=2-x*inv;inv=-inv;}
 U mul(U x,U y) const{W z=(W)x*y;U k=(U)z*inv;W t=z+(W)k*m;U h=t>>64;return h<m?h:h-m;}
 U pow(U a,U e,U one)const{U b=one;while(e){if(e&1)b=mul(b,a);a=mul(a,a);e>>=1;}return b;}
};
int main(int argc,char**argv){
 U a=strtoull(argv[1],0,10),b=strtoull(argv[2],0,10); a|=1;
 for(int depth=8;depth<=11;depth++){
 const U M=pow7(depth),T=6*(M/7),H=pow7(6),T0=6*H/7,Q=M/H,lo=std::max(a,T/7+1)|1,hi=std::min(b,T-1);
 if(hi<lo)continue;
 U step=(powm(10,T0,M)-1)/H,istep=powm(step,6*Q/7-1,Q);
 std::vector<U> residue(H),ir(H);
 const U fac=powm(10,6,M),ifac=powm(fac,T-1,M); U unit=18000%M,iunit=powm(unit,T-1,M);
 for(U r=3;r<T0;r+=6){
  residue[unit%H]=r;ir[unit%H]=iunit;
  unit=(W)unit*fac%M;iunit=(W)iunit*ifac%M;
 }
 U x=powm(10,lo,M);U checked=0,actual=0;
 for(U l=lo;l<=hi;l+=2,x=100*x%M){
  U s=7*l-4;if(s%5==0)continue;
  U y=(7*x+M-25)%M;U c=y%H;
  U z=((U)((W)y*ir[c]%M)-1)/H;
  U i=residue[c]+T0*(z*istep%Q);
  checked++;
  if(i>=l)continue;
  actual++;
  U m=9*s;Mont mm(m);U one=((W)1<<64)%m;U base=one*10%m;
  U u=mm.pow(base,l,one),v=mm.pow(base,i,one);
  if((7*u+18*m-18*v)%m==25*one%m){
   printf("hit L=%llu i=%llu K=%d S=%llu\n",l,i,depth,s);fflush(stdout);
  }
 }
 fprintf(stderr,"depth=%d range=%llu..%llu checked=%llu actual=%llu\n",depth,lo,hi,checked,actual);
 }
}
