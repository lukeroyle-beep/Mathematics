#define main scan_main
#include "scan.cpp"
#undef main
#include <random>
int main(){
  std::mt19937_64 rng(371997);
  for(int j=0;j<20000;++j){
    U p=7+rng()%20000, a=rng()%p, b=rng()%p;
    U n=1+rng()%350,lim=1+rng()%(p-1),s=0,num=0;
    m=p;
    for(U k=0;k<n;++k){
      s+=(a*k+b)/p;
      if((a*k+b)%p<lim)num++;
    }
    if(s!=floors(n,p,a,b)||num!=nhit(n,a,b,lim))return 1;
  }
  return 0;
}
