#include <algorithm>
#include <array>
#include <charconv>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

using i64 = std::int64_t;
using u64 = std::uint64_t;
using u128 = __uint128_t;

constexpr u64 seven_power(int exponent) {
    u64 value = 1;
    for (int j = 0; j < exponent; ++j) value *= 7;
    return value;
}

template<u64 Mod>
inline u64 multiply(u64 x, u64 y) {
    return static_cast<u64>(static_cast<u128>(x) * y % Mod);
}

template<u64 Mod>
u64 power10(u64 exponent) {
    u64 result = 1, base = 10;
    while (exponent) {
        if (exponent & 1) result = multiply<Mod>(result, base);
        base = multiply<Mod>(base, base);
        exponent >>= 1;
    }
    return result;
}

template<u64 Mod>
inline u64 difference(u64 x, u64 y) {
    const u64 sub = (y + 25) % Mod;
    return x >= sub ? x - sub : Mod - (sub - x);
}

i64 floor_div(i64 a, i64 b) {
    if (b <= 0) throw std::logic_error("floor_div requires positive denominator");
    return a / b - (a % b < 0);
}

i64 ceil_div(i64 a, i64 b) { return -floor_div(-a, b); }

i64 inverse(i64 a, i64 modulus) {
    i64 x = 1, prev_x = 0, r = a, prev_r = modulus;
    while (r) {
        const i64 q = prev_r / r;
        const i64 next_r = prev_r - q*r, next_x = prev_x - q*x;
        prev_r = r; r = next_r; prev_x = x; x = next_x;
    }
    if (prev_r != 1) throw std::logic_error("nonunit at inverse");
    return (prev_x % modulus + modulus) % modulus;
}

// All (v,j) with j = intercept + slope*v (mod P) in the specified box.
// The successive remainder vectors form a basis with determinant +/- P.
template<i64 P, class Visit>
void points(i64 slope, i64 intercept, i64 vmax, i64 jmax, i64 target, Visit visit) {
    if (vmax < 0 || jmax < 0) return;
    i64 sx = 0, sy = P, x = 1, y = slope;
    while (y > target) {
        const i64 q = sy / y;
        const i64 nx = sx - q*x, ny = sy - q*y;
        sx = x; sy = y; x = nx; y = ny;
    }
    if (x < 0) { x = -x; y = -y; }
    if (x*sy - y*sx == -P) { sx = -sx; sy = -sy; }
    if (x <= 0 || x*sy - y*sx != P) throw std::logic_error("basis determinant");

    // x*(j-intercept) - y*v = n*P on each parallel lattice line.
    const i64 bottom = -x*intercept - std::max<i64>(0,y*vmax);
    const i64 top = x*(jmax-intercept) - std::min<i64>(0,y*vmax);
    for (i64 n=ceil_div(bottom,P); n<=floor_div(top,P); ++n) {
        const i64 v0=n*sx, j0=intercept+n*sy;
        i64 lo=ceil_div(-v0,x), hi=floor_div(vmax-v0,x);
        if (y>0) {
            lo=std::max(lo,ceil_div(-j0,y));
            hi=std::min(hi,floor_div(jmax-j0,y));
        } else if (y<0) {
            lo=std::max(lo,ceil_div(j0-jmax,-y));
            hi=std::min(hi,floor_div(j0,-y));
        } else if (j0<0 || j0>jmax) {
            continue;
        }
        for (i64 m=lo; m<=hi; ++m) visit(v0+m*x,j0+m*y);
    }
}

template<int D>
void sieve(i64 limit, const std::string& output) {
    constexpr i64 P=seven_power(D-1), U=6*(P/7), V=7*U;
    constexpr u64 M=seven_power(2*D-1), F=seven_power(2*D+2), PD=seven_power(D);
    if (limit<5 || limit>1000000000000LL) throw std::runtime_error("length bound outside supported domain");
    // For small regression depths use modest limits so signed products remain bounded.
    if (limit/U>100000) throw std::runtime_error("base depth too low for supplied limit");
    std::ofstream out(output);
    if (!out) throw std::runtime_error("cannot open output file");
    std::vector<std::int32_t> log10_mod(P, -1);
    std::vector<u64> odd_powers(U/2);
    u64 xp=1, xm=1;
    for (i64 h=0; h<U; ++h) {
        if (log10_mod[xp]!=-1) throw std::logic_error("unexpected period");
        log10_mod[xp]=static_cast<std::int32_t>(h);
        if (h&1) odd_powers[h/2]=xm;
        xp=(10*xp)%P; xm=multiply<F>(xm,10);
    }
    if (xp!=1) throw std::logic_error("period not closed");

    const u64 high_u=power10<F>(U), high_v=power10<F>(V);
    std::vector<u64> j_powers(limit/U+1,1), v_powers(limit/V+1,1);
    for (std::size_t n=1; n<j_powers.size(); ++n) j_powers[n]=multiply<F>(j_powers[n-1],high_u);
    for (std::size_t n=1; n<v_powers.size(); ++n) v_powers[n]=multiply<F>(v_powers[n-1],high_v);
    const u64 pow_u=high_u%M, pow_v=high_v%M;
    if ((pow_u-1)%P || (pow_v-1)%PD) throw std::logic_error("wrong lifting modulus");
    const i64 a=((pow_u-1)/P)%P, b=((pow_v-1)/PD)%P;
    const i64 inv_a=inverse(a,P);
    i64 target=1;
    while ((target+1)*(target+1)<=7*P) ++target;

    u64 high_y=1000%F, groups=0, candidates=0, next_count=0, second_count=0, retained=0;
    for (i64 r=3; r<V; r+=6, high_y=multiply<F>(high_y,1000000)) {
        const u64 y=high_y%M;
        // 18*y+25 is a multiple of 7 and fits in unsigned 64 bits for D<=10.
        const u64 numerator=18*y+25;
        if (numerator%7) throw std::logic_error("residue lifting error");
        const i64 h=log10_mod[(numerator/7)%P];
        if (h<0 || h%2==0) continue;
        ++groups;
        if (h>limit || r>=limit) continue;
        const u64 high_x=odd_powers[h/2];
        const u64 x=high_x%M;
        const u64 remainder=difference<M>((7*x)%M,(18*y)%M);
        if (remainder%PD) throw std::logic_error("base exponent pair");
        const i64 c=remainder/PD;
        const i64 inv_x=odd_powers[(U-h)/2]%P;
        const i64 inv_linear=(inv_a*inv_x)%P;
        const i64 slope=((18*(y%P)*b)%P*inv_linear)%P;
        const i64 intercept=((P-c)*inv_linear)%P;
        const i64 jmax=(limit-h)/U, vmax=(limit-1-r)/V;
        points<P>(slope,intercept,vmax,jmax,target,[&](i64 v,i64 j) {
            const i64 L=h+j*U, i=r+v*V;
            if (L<5 || i>=L) return;
            ++candidates;
            const u64 l_power=multiply<F>(high_x,j_powers[j]);
            const u64 i_power=multiply<F>(high_y,v_powers[v]);
            const u64 z=difference<F>(multiply<F>(7,l_power),multiply<F>(18,i_power));
            if (z%M) throw std::logic_error("affine candidate validation");
            if (z%(7*M)==0) ++next_count;
            if (z%(49*M)==0) ++second_count;
            if (z) return;
            ++retained; out<<L<<' '<<i<<'\n';
        });
    }
    if (groups!=static_cast<u64>(U/2)) throw std::logic_error("incomplete base classes");
    out.close();
    if (!out) throw std::runtime_error("could not write all retained pairs");
    std::cout<<"limit "<<limit<<" base_depth "<<D<<" groups "<<groups
             <<" depth_"<<(2*D-1)<<" "<<candidates
             <<" depth_"<<(2*D)<<" "<<next_count<<" depth_"<<(2*D+1)<<" "<<second_count
             <<" depth_"<<(2*D+2)<<" "<<retained<<'\n';
}

int main(int argc,char** argv) {
    try {
        if (argc!=4) throw std::runtime_error("usage: lattice BASE_DEPTH MAX_LENGTH OUTPUT");
        const int d=std::stoi(argv[1]);
        const i64 limit=std::stoll(argv[2]);
        switch(d) {
            case 3: sieve<3>(limit,argv[3]); break;
            case 4: sieve<4>(limit,argv[3]); break;
            case 5: sieve<5>(limit,argv[3]); break;
            case 6: sieve<6>(limit,argv[3]); break;
            case 7: sieve<7>(limit,argv[3]); break;
            case 8: sieve<8>(limit,argv[3]); break;
            case 9: sieve<9>(limit,argv[3]); break;
            case 10: sieve<10>(limit,argv[3]); break;
            default: throw std::runtime_error("supported base depths 3 through 10");
        }
    } catch(const std::exception& e) {
        std::cerr<<e.what()<<'\n'; return 1;
    }
}
