# Exact valuation scan for odd lengths up to 1,000,000,000,000

The domain is odd 5 ≤ L ≤ B=10^12 and integer 3 ≤ i < L. Set F=7·10^L−18·10^i−25. Write T_k=6·7^(k−1). Since 10 mod 7 has order 6 and 10^6−1 is divisible by 7 exactly once, the binomial theorem gives ord_(7^k)(10)=T_k for k≥1.

## Residue classes

At depth d, enumerate h odd with 1 ≤ h < T_(d−1). For each h there is exactly one r in [0,T_d) with 7·10^h−18·10^r−25=0 mod 7^d. The right-hand side defining 10^r is a 7-adic unit. The multiplicative group has T_d elements and 10 is a generator. The L-period is T_(d−1) because its leading coefficient is 7. Hence all pairs with valuation at least d are represented uniquely in the form L=h+j·T_(d−1), i=r+v·T_d with j,v ≥ 0 for pairs in the domain.

Implementation starts at depth 2 by testing h=1,3,5 and 0 ≤ r <42 mod49. A depth-k seed has children h'=h+s·T_(k−1), r'=r+t·T_k, 0 ≤ s,t <7. Write x=10^h, y=10^r, U=10^T_(k−1), V=10^T_k. Modulo 7^(k+1), expand U^s and V^t through first order. Then t is uniquely fixed modulo 7 by
  18y [(V−1)/7^k] t ≡ F(h,r)/7^k + x[(U−1)/7^(k−1)]s.
The bracket multiplying t and 18y are units. All omitted terms have valuation at least k+1, including 1+2(k−1) ≥ k+1 at k=2. At d=11 the number of leaves is T_10/2 = 121,060,821.

## Linear lifting at each leaf

Set m=7^(d−1) and M=7^(2d−1). Modulo M, square and higher terms in each of 7xU^j and 18yV^v vanish because v7(7(U−1)^2)=2d−1 and v7((V−1)^2)=2d. Consequently the exact depth-(2d−1) test is
  v ≡ (F(h,r)/7^d + x[(U−1)/7^(d−1)] j) · (18y[(V−1)/7^d])^(−1) mod m.
All powers retained for RHS construction can use representatives mod M. Each cross-multiplied coefficient is determined mod m. Call the right side c+aj.

The rectangle uses 0 ≤ j < n=floor((B−h)/T_(d−1))+1 and 0 ≤ v < u=floor((B−r)/T_d)+1; skip negative ranges. Here n,u < m, so a j has exactly one qualifying v if its least residue is below u. The number in any shifted j range is the sum of
  floor((aj+c)/m)−floor((aj+c−u)/m).
The helper floors computes the sum of floors by standard Euclidean reciprocity. After reducing a,b modulo m and adding the extracted quotient terms, let y=a n+b. If y<m, all terms vanish. Otherwise the new arguments are (floor(y/m),a,m,y mod m), counting the same lattice points after exchanging the axes. This recursion is the integer identity used in AtCoder's floor_sum implementation. Negative initial b is handled by adding m and subtracting n. The scan splits nonempty ranges, enumerates small ranges directly and applies the inequalities 5 ≤ L, 3 ≤ i < L. Direct modular exponentiation checks each survivor at depth 22; Python checks depth 22 afresh and increments the depth until the first failure.

## Integer bounds

At d=11, M=7^21=558545864083284007; 18(M−1)+25 < 2^64 and 7(M−1)<2^64. The unsigned difference reducer takes the sign into account before reducing; products of residues modulo M and 7^22 use 128-bit products. Modular affine coefficients live modulo m=7^10=282475249, with m^2<2^64. For B=10^12, n ≤ 4131, u ≤ 591; with c,a<m the floor sums in individual initial rectangles are smaller than n(n+1)/2, and after normalizing slopes the Euclidean reciprocity steps do not increase n and strictly lower the positive modulus. The intermediate expression n(n−1)/2 times the quotient is bounded by the floor sum being computed. Even unevaluated n(n−1)/2·m fits in 64 bits at these values. The range test (7x+19·7^22−18y−25) mod 7^22 at the last stage uses 128 bits. Only the explicitly diagnostic additive signature uses wraparound modulo 2^64. No floating point is used.

## Reproduction

From the source directory on a machine with GCC and Python 3:

    g++ -std=c++17 -O3 -DDEPTH=11 scan.cpp -o scan11
    ./scan11 1000000000000 > results12.txt
    python cross.py results12.txt

Python writes an ordered no-header CSV next to the input results. The mathematical result and ordered CSV are independent of compiler optimizations. For the direct small-domain control compile with -DDEPTH=3 and use B=1800, then directly test every odd L ≤1800 and every 0 ≤ i ≤1800 mod7^5. The two procedures find 113 rectangle hits and 64 domain hits; both diagnostic sums equal 7261989003630623330 mod 2^64.

At B=10^12 there are 1,044,321 rectangle hits and 522,020 domain hits at depth 21, with 74,601 domain hits at depth 22. For depths 22 through 27 the exact valuations respectively occur 63974, 9161, 1272, 162, 29 and 3 times. No pair reaches 28. The sorted CSV SHA-256 is 919c091c978ee1e6011f9239fadbba675985714f286d8dcffa1a29ed043cf8e4.
