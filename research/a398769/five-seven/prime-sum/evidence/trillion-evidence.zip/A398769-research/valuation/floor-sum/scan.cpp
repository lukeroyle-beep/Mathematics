#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <vector>

using U=uint64_t;
using W=__uint128_t;

#ifndef DEPTH
#define DEPTH 10
#endif
constexpr int D=DEPTH;
static_assert(D >= 3 && D <= 11, "Supported lifting depths are 3 through 11");
U bound, md, m, primepower, invscale, axscale, threshold22;
U p7[32], period[25], xp[15][7], yp[15][7], yinvp[15][7];
U seeds=0, rect=0, valid=0, pass22=0, signature=0;
U mul(U x,U y,U mod){return W(x)*y%mod;}
U powm(U x,U n,U mod){U v=1; while(n){if(n&1)v=mul(v,x,mod);x=mul(x,x,mod);n>>=1;}return v;}
U inv(U x,U mod){return powm(x,mod/7*6-1,mod);}
U rem(int64_t x,U mod){auto t=x%int64_t(mod);return t<0?t+mod:t;}
U F(U x,U y,U mod){
  U a=7*x,b=18*y+25;
  if(a>=b)return (a-b)%mod;
  U t=(b-a)%mod;return t?mod-t:0;
}
U floors(U n,U mod,U a,U b){
  U s=0;
  while(true){
    if(a>=mod){s+=(n*(n-1)/2)*(a/mod);a%=mod;}
    if(b>=mod){s+=n*(b/mod);b%=mod;}
    U last=a*n+b;
    if(last<mod)return s;
    n=last/mod;b=last%mod;std::swap(a,mod);
  }
}
U nhit(U n,U a,U c,U lim){
  if(c>=lim)return floors(n,m,a,c)-floors(n,m,a,c-lim);
  return floors(n,m,a,c)+n-floors(n,m,a,c+m-lim);
}
void control(U L,U i){
  U val1=powm(10,L,threshold22),val2=powm(10,i,threshold22);
  if((W(7)*val1+W(19)*threshold22-W(18)*val2-25)%threshold22)return;
  ++pass22;
  std::cout<<"depth22 "<<L<<" "<<i<<"\n";
}
void hits(U j0,U n,U c,U a,U lim,U h,U r){
  if(n<=30){
    for(U k=0;k<n;++k){
      if(c<lim){
        ++rect;
        U L=h+(j0+k)*period[D-1],i=r+c*period[D];
        if(L>=5 && i>=3 && i<L){
          ++valid;signature+=L*0x22dd3ec102b93f9bULL+i;
          control(L,i);
        }
      }
      c+=a;if(c>=m)c-=m;
    }
    return;
  }
  if(!nhit(n,a,c,lim))return;
  U k=n/2;
  hits(j0,k,c,a,lim,h,r);
  hits(j0+k,n-k,(c+a*k)%m,a,lim,h,r);
}
void leaf(U h,U r,U x,U y,U yi){
  ++seeds;
  if(h>bound || r>bound)return;
  U n=(bound-h)/period[D-1]+1,lim=(bound-r)/period[D]+1;
  if(n>=m || lim>=m)throw std::runtime_error("increase depth");
  U f=F(x,y,primepower);
  if(f%md)throw std::runtime_error("bad seed");
  U unit=(yi*invscale)%m;
  U a=(((x%m)*axscale)%m*unit)%m;
  U c=(f/md*unit)%m;
  hits(0,n,c,a,lim,h,r);
}
void tree(int k,U h,U r,U x,U y,U yi){
  if(k==D){leaf(h,r,x,y,yi);return;}
  U div=p7[k];
  U den=(18*(y%7)*((yp[k][1]-1)/div%7))%7;
  U di=inv(den,7);
  U t0=(F(x,y,p7[k+1])/div*di)%7;
  U slope=(x%7*((xp[k][1]-1)/p7[k-1]%7)*di)%7;
  for(U s=0;s<7;++s){
    U t=(t0+s*slope)%7;
    tree(k+1,h+s*period[k-1],r+t*period[k],
      mul(x,xp[k][s],primepower),mul(y,yp[k][t],primepower),(yi*yinvp[k][t])%m);
  }
}
int main(int argc,char**argv){
  bound=argc>1?std::strtoull(argv[1],nullptr,10):100000000000ULL;
  if (bound < 5 || bound > 1000000000000ULL) {
    std::cerr << "Length bound must be between 5 and one trillion.\n";
    return 1;
  }
  p7[0]=1;for(int k=1;k<=22;++k)p7[k]=p7[k-1]*7;
  for(int k=1;k<=20;++k)period[k]=6*p7[k-1];
  primepower=p7[2*D-1];m=p7[D-1];md=p7[D];threshold22=p7[22];
  for(int k=2;k<=D;++k){
    for(int s=0;s<7;++s){
      xp[k][s]=powm(10,s*period[k-1],primepower);
      yp[k][s]=powm(10,s*period[k],primepower);
      yinvp[k][s]=inv(yp[k][s]%m,m);
    }
  }
  invscale=inv(18*((yp[D][1]-1)/md)%m,m);
  axscale=(xp[D][1]-1)/p7[D-1]%m;
  for(U h=1;h<6;h+=2)for(U r=0;r<42;++r){
    U x=powm(10,h,primepower),y=powm(10,r,primepower);
    if(F(x,y,49)==0)tree(2,h,r,x,y,inv(y%m,m));
  }
  std::cout<<"B "<<bound<<" seeds "<<seeds<<" rectangular "<<rect<<" domainDepth "<<2*D-1<<" domainCount "<<valid<<" pass22 "<<pass22<<" sig "<<signature<<"\n";
  return 0;
}
