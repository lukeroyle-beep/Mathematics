"""Verify the complete retained list using the original decimal number."""
import csv
import hashlib
from collections import Counter
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def original_decimal(length, position):
    digits = ["7"] * length
    digits[-1] = digits[-position-1] = "5"
    return int("".join(digits))


def main():
    source = Path(__file__).with_name("candidates.csv")
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    require(digest == "919c091c978ee1e6011f9239fadbba675985714f286d8dcffa1a29ed043cf8e4",
            "unexpected ordered list")
    exact_counts = Counter()
    maximum_pairs = []
    previous = (0, 0)
    modulus = 7**28
    with source.open(newline="") as records:
        for row in csv.reader(records):
            length, position = map(int, row)
            require(previous < (length, position), "duplicate or out of order")
            previous = length, position
            require(5 <= length <= 10**12 and length % 2 == 1 and 3 <= position < length,
                    "outside the claimed domain")
            # The repunit is obtained modulo 7^28 by exact division before reduction.
            repunit = (pow(10, length, 9 * modulus) - 1) // 9
            residue = (7 * repunit - 2 * (pow(10, position, modulus) + 1)) % modulus
            require(residue != 0, "depth 28 requires further checking")
            depth = 0
            while residue % 7 == 0:
                residue //= 7
                depth += 1
            require(depth >= 22, "false positive in supplied list")
            exact_counts[depth] += 1
            if depth == 27:
                maximum_pairs.append((length, position))
    expected_counts = {22: 63974, 23: 9161, 24: 1272, 25: 162, 26: 29, 27: 3}
    require(exact_counts == expected_counts, "valuation distribution differs")
    # For L>=30 the bound 27<L-2 suffices. The remaining odd lengths fit here.
    small_count = 0
    for length in range(5, 30, 2):
        for position in range(3, length):
            n = original_decimal(length, position)
            require(n % 7**(length-2) != 0, "small length reaches threshold")
            small_count += 1
    print("Retained-list SHA-256", digest)
    print("Exact valuations", sorted(exact_counts.items()))
    print("Maximum pairs", maximum_pairs)
    print("Small literal decimal words checked", small_count)


if __name__ == "__main__":
    main()
