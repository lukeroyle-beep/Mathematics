"""Cross-check a small sieve with a direct modular table and validate the large survivors."""
from argparse import ArgumentParser
from pathlib import Path
import hashlib
import subprocess
import tempfile


def require(value, message):
    if not value:
        raise ValueError(message)


def load_pairs(path):
    lines = Path(path).read_text().splitlines()
    pairs = [tuple(map(int, line.split())) for line in lines]
    require(len(set(pairs)) == len(pairs), "duplicate candidate")
    return pairs


def check_small(executable):
    for depth, upper in [(3, 25000), (4, 70000)]:
        levels = [2 * depth - 1, 2 * depth + 2]
        brute_sets = []
        for level in levels:
            mod = 7**level
            positions = {}
            for i in range(3, upper, 6):
                positions.setdefault(18*pow(10,i,mod)%mod, []).append(i)
            pairs = set()
            for length in range(5, upper + 1, 2):
                wanted = (7 * pow(10, length, mod) - 25) % mod
                for i in positions.get(wanted, []):
                    if i < length:
                        pairs.add((length, i))
            brute_sets.append(pairs)
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder) / "pairs"
            cmd = [str(executable), str(depth), str(upper), str(output)]
            line = subprocess.check_output(cmd, text=True).split()
            require(int(line[line.index("depth_" + str(levels[0])) + 1]) == len(brute_sets[0]), "first sieve count")
            require(int(line[-1]) == len(brute_sets[1]), "second sieve count")
            require(set(load_pairs(output)) == brute_sets[1], "small sieve pairs")
        print("small_control", depth, upper, *(len(pairs) for pairs in brute_sets))


def inspect_file(path, upper, sorted_output=None):
    counts = {k: 0 for k in range(22, 31)}
    witnesses = []
    maximum = (0, [])
    pairs = sorted(load_pairs(path))
    canonical = "".join(f"{length} {position}\n" for length, position in pairs).encode("ascii")
    print("sorted_depth_22_sha256", hashlib.sha256(canonical).hexdigest())
    if sorted_output:
        Path(sorted_output).write_bytes(canonical)
    for length, position in pairs:
        require(5 <= length <= upper and length % 2 and 3 <= position < length and position % 6 == 3, "pair domain")
        for level in range(22, 41):
            mod = 7**level
            value = (7*pow(10,length,mod)-18*pow(10,position,mod)-25) % mod
            if value:
                break
            if level in counts:
                counts[level] += 1
        else:
            raise ValueError("increase diagnostic depth")
        require(level > 22, "false depth-22 candidate")
        valuation = level - 1
        if valuation > maximum[0]:
            maximum = (valuation, [])
        if valuation == maximum[0]:
            maximum[1].append((length, position))
        if valuation >= length - 2:
            digit_sum = 7*length-4
            mod = 225*digit_sum*7**(length-2)
            if (7*pow(10,length,mod)-18*pow(10,position,mod)-25) % mod == 0:
                witnesses.append((length, position))
    print("depth_counts", counts)
    print("max_depth", maximum)
    print("witnesses_in_survivor_file", witnesses)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--executable", type=Path)
    parser.add_argument("--survivors", type=Path)
    parser.add_argument("--upper", type=int)
    parser.add_argument("--sorted-output", type=Path)
    args = parser.parse_args()
    if args.executable:
        check_small(args.executable.resolve())
    if args.survivors:
        inspect_file(args.survivors, args.upper, args.sorted_output)
