import sys
from pathlib import Path
from collections import Counter
import hashlib
source=Path(sys.argv[1] if len(sys.argv)>1 else 'results.txt')
res=source.read_text().splitlines()
B=int(res[-1].split()[1])
pairs=[tuple(map(int,s.split()[1:])) for s in res if s.startswith('depth22 ')]
if len(pairs)!=len(set(pairs)):raise ValueError("duplicate pair")
hist=Counter()
examples={}
for L,i in pairs:
    if not (5<=L<=B and L%2 and 3<=i<L):raise ValueError((L,i,"domain"))
    k=22
    def divisible(j):
        m=7**j
        return (7*pow(10,L,m)-18*pow(10,i,m)-25)%m ==0
    if not divisible(k):raise ArithmeticError((L,i,k))
    while divisible(k+1):k+=1
    hist[k]+=1
    examples[k]=(L,i)
print(res[-1])
print('raw22',len(pairs),'histogram',sorted(hist.items()))
print('max',max(hist,default=None),'example',examples.get(max(hist,default=None)))
raw=''.join(f'{L},{i}\n' for L,i in sorted(pairs))
source.with_name(f'candidates{B}.csv').write_text(raw)
print('ordered_csv_sha256', hashlib.sha256(raw.encode()).hexdigest())
