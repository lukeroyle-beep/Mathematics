# A398769 on digits 5 and 7

26 November 2026

**Outcome.** Every length from 1 through **1,000,000,000,000** is excluded. Across the reduced family the largest seven-adic valuation in this interval is **27**. The all-length problem remains open. No witness or effective upper limit on the length of a witness was found.

## Why the computation settles the full interval

Let L denote the number of digits and i the position of the second five, counting from zero at the units digit. Every possible witness has odd L at least five and 3 ≤ i < L. Its digits are seven except for the fives at zero and i. If F = 7·10^L − 18·10^i − 25, the integer is n = F/9, its digit product is 25·7^(L−2), and its digit sum is S = 7L−4. The exact condition is 225·S·7^(L−2) | F. In particular, v₇(F), the exponent of seven in F, must be at least L−2. [Audited reduction](https://github.com/lukeroyle-beep/Mathematics/blob/37bd10a930d6dc7c9a7bcfd8db7588451dc26da2/research/a398769/five-seven/settlement/README.md).

For completeness, the reduction starts with the fact that the number is odd, so its digit sum must be odd and L is odd. With no fives, the number is seven times a decimal repunit; seven does not divide that repunit at an odd length, since 10 has order six modulo seven. With exactly one five it must occupy the units place, and nine times the number is 7·10^L−25, a unit modulo seven for L≥2. The single-digit cases fail directly. Three or more fives would require divisibility by 125, impossible for any three-digit suffix made of fives and sevens ending in five. With exactly two fives one is at the units place and the growing seven-power forces i ≡ 3 modulo 6 for L≥3. This gives the stated domain.

Two exhaustive algorithms enumerated every pair in the stated domain at which 7^22 divides F. Both produced precisely the same **74,601 pairs**, matching entry by entry after sorting. The first parameterized by the position residue and enumerated integer lattice points. The second recursively lifted residues of the length and counted points between two straight lines using sums of integer floors. They used different initial depths, 10 and 11. Their intermediate count also agreed at depth 21, with 522,020 pairs. A third implementation evaluated each retained pair using the original decimal number expressed as a repunit with two altered digits.

| Exact v₇(F) | 22 | 23 | 24 | 25 | 26 | 27 | 28 or more |
|---|---:|---:|---:|---:|---:|---:|---:|
| Pairs | 63,974 | 9,161 | 1,272 | 162 | 29 | 3 | 0 |

The three maximizing pairs have the following exact residues. Division by 7^27 in this table means taking the residue modulo 7^28 and dividing it by 7^27.

| L | i | F/7^27 modulo 7 | F modulo 9S |
|---:|---:|---:|---:|
| 206,013,221,471 | 70,699,701,213 | 5 | 3,856,899,186,774 |
| 636,442,113,223 | 552,133,548,915 | 4 | 26,953,514,010,765 |
| 778,826,473,305 | 776,307,582,249 | 1 | 41,862,190,888,350 |

For L ≥ 30 the required depth L−2 exceeds 27. For the smaller odd lengths from 5 through 29, direct construction of all 182 reduced decimal words found none divisible by 7^(L−2). The inherited elementary reduction covers the remaining digit patterns and lengths. The proof therefore uses fresh finite computations across the interval and the established elementary reduction. The bound chosen for the search was 10^12. Its endpoint has no special role in the proof at larger lengths.

## Results for unbounded lengths

1. **Almost every length fails the digit-sum test before any growing power of seven is imposed.** The lengths L for which 7L−4 divides F(L,i) for even one nonnegative exponent i have natural density zero. This means their proportion up to X tends to zero, including within every fixed arithmetic progression. The proof uses primes p ≡ 1 modulo 40 dividing 7L−4. For each such prime, 18·10^i is always a square. A quadratic nonresidue for 7·10^L−25 rules out every exponent simultaneously. Character-sum estimates and a second-moment argument show that successive finite sets of primes exclude a fixed fraction of each surviving progression. The argument leaves exceptional lengths. The project already exhibits infinitely many lengths that pass the full digit-sum test at actual positions. [Proof with sources](proofs/digit-sum-density.md). [Existing fixed-depth constructions](https://github.com/lukeroyle-beep/Mathematics/blob/37bd10a930d6dc7c9a7bcfd8db7588451dc26da2/research/a398769/five-seven/fixed-depth/README.md).
2. **Whole intervals of position ratios are excluded at every length.** For each reduced fraction 0 < a/b < 1 with b ≤ 55, every hypothetical witness satisfies |bi−aL| > L/(100000 b²). This excludes the centre and both endpoints of each strip. The new finite certificate covers the initial lengths needed for the analytical estimate in the merged record. A further, narrower inequality applies to every denominator away from the exact centre. [Proof and constants](proofs/rational-strips.md). [Merged analytic estimate, equation (13)](https://github.com/lukeroyle-beep/Mathematics/blob/37bd10a930d6dc7c9a7bcfd8db7588451dc26da2/research/a398769/five-seven/uniform-bound/ANALYTIC.md).
3. **Two hypothetical witness lengths must be far apart.** If m < M both attain their own required valuation and m ≥ 105, then M > 5m/4. More generally, if v is the smaller valuation attained at any two selected positions at these distinct lengths, then 25·7^(3v) < 10^(2M). An isolated high valuation is consistent with this inequality. [Elementary proof](proofs/two-length-gap.md).
4. **Prime and composite digit sums admit explicit tests.** For prime S = 7L−4, a necessary sixth-power test rejects exactly two thirds of the primes S ≡ 3 modulo 7 in relative natural density. For composite S divisible by any decimal repunit (10^m−1)/9 with m ≥ 3, every position fails the full digit-sum condition. For example, all lengths 476,190,476,190,476,191 + 2,222,222,222,222,222,222 t with integer t ≥ 0 are excluded. [Proofs and controls](proofs/prime-sums-and-repunits.md).

## Separate finite result for early rejection

Let K(L) be the first k with 6·7^(k−1) > L. The proposed all-length implication (E) asserts that at odd L ≥ 5 with 5 not dividing S, divisibility by 9S forces v₇(F) < K(L). Two additional programs checked all 842,425,747 odd lengths from 10,000,001 through 1,694,851,493. There were 385,825,287 actual positions at depth K(L) after excluding sums divisible by five. None passed 9S | F. This extends the earlier (E) certificate to every odd L from 5 through **1,694,851,493**. The all-length implication remains open. [Reproduction, band counts and source](early-rejection/README.md).

## Reproduce and audit

The bundle contains the full sorted list at depth 22, both finite enumeration programs and the third decimal-form checker. The primary finite result can be reproduced on a machine with GNU C++ and Python 3. Start in the valuation folder.

```sh
g++ -O3 -std=c++17 lattice/lattice.cpp -o lattice-run
./lattice-run 10 1000000000000 lattice-pairs.txt
python3 lattice/verify.py --executable ./lattice-run --survivors lattice-pairs.txt --upper 1000000000000 --sorted-output lattice-sorted.txt

g++ -O3 -std=c++17 -DDEPTH=11 floor-sum/scan.cpp -o floor-run
./floor-run 1000000000000 > floor-pairs.txt
python3 floor-sum/cross.py floor-pairs.txt
cmp candidates.csv candidates1000000000000.csv
tr ' ' ',' < lattice-sorted.txt | cmp - candidates.csv
python3 check_decimal.py
```

The SHA-256 (Secure Hash Algorithm, 256-bit) digest of the sorted list, with comma-separated integers and a newline after every pair, is `919c091c978ee1e6011f9239fadbba675985714f286d8dcffa1a29ed043cf8e4`. Both complete enumerations were freshly compiled and rerun and their lists compared with this file. Finite calculations use exact integer arithmetic. The supporting arguments are ordinary mathematical proofs and are available for independent audit. No new Lean theorem is claimed.

## The remaining problem

The project proves v₇(F) = o(L) uniformly as L grows. This implies that only finitely many pairs can be full witnesses, but it gives no last length to test. A single exceptional pair above one trillion, outside the excluded strips and with 225·S·7^(L−2) | F, remains consistent with the results here. The complete {5,7} subclass and the wider digit-1 conjecture both remain open. [Qualitative bound](https://github.com/lukeroyle-beep/Mathematics/blob/37bd10a930d6dc7c9a7bcfd8db7588451dc26da2/research/a398769/five-seven/effective/QUALITATIVE.md). [Starting research record](https://github.com/lukeroyle-beep/Mathematics/pull/20).
