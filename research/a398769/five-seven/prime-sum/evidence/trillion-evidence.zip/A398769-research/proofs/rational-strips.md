# Simultaneous exclusions around rational position ratios

Let \(0<a<b\) be coprime integers and put \(\delta=bi-aL\). For every full witness at every length,
\[
 \delta=0\quad\text{or}\quad
 |\delta|>\frac{L}{100000\,b^4(b+2)}.
\]
If \(a\) is even, \(b\) is even, or \(7\mid a\), the conclusion also excludes \(\delta=0\). These centres therefore have a closed positive-width exclusion strip at all lengths. In terms of the actual ratio \(i/L\), the half-width is \(1/(100000\,b^5(b+2))\).

**Proof.** The inherited finite certificate covers \(L\le10^7\). In the remaining domain, \(L\) is odd, \(i\equiv3\pmod6\), and any witness has \(t=v_7(F(L,i))\ge L-2\). Suppose \(1\le|\delta|\le L/(100000 b^4(b+2))\). Integrality of \(\delta\) implies \(b\le L\). Use the polynomial construction with \(q=\lfloor L/b\rfloor\), coefficient span \(w\), and initial height parameter \(H=w+2\). Its published span estimate yields
\[
 H\le |\delta|/b+b+1\le (b+2)|\delta|
     \le H'=\frac{L}{100000\,b^4}.
\]
In particular \(H'\ge H\ge2\), so \(H'\) is a permitted height parameter in the two-logarithm bound. Write \(d\) for the derivative valuation in that construction. For a possible full witness, the published branch elimination and derivative estimate give \(d<(L-2)/2\) and
\[
 t\le d+63 b^3 H'
 \max\left\{20,\log\big((q/H'+1)/\log10\big)+\log\log7+0.4\right\}^2.
\]
Here and below \(\log\) denotes the natural logarithm. Since \(q/H'\le100000 b^3\), the second argument of the maximum is less than \(14+3\log b\). For example, use \(q/H'+1\le200000 b^3\), \(\log10>1\), \(\log(200000)<13\) and the sharper combined inequality \(\log(200000)+\log\log7+0.4<14\). Also \(\log b\le2(\sqrt b-1)\). The maximum is therefore at most \(20+3\log b\le20\sqrt b\). Substitution gives
\[
 t < (L-2)/2 + 63\cdot400\,L/100000
       = (L-2)/2 + 0.252L<L-2,
\]
a contradiction. The analytic estimate, its height assumptions, and derivative and branch bounds are in [the merged analytic proof, equations (2), (4), (7)–(13)](https://github.com/lukeroyle-beep/Mathematics/blob/37bd10a930d6dc7c9a7bcfd8db7588451dc26da2/research/a398769/five-seven/uniform-bound/ANALYTIC.md).

When \(\delta=0\), coprimality gives \(L=bh\), \(i=ah\) for some positive integer \(h\). Oddness of both \(L\) and \(i\) rules out either even parameter. The inherited modulo-49 condition gives \(i\bmod7\in\{1,3,4\}\), ruling out \(7\mid a\). For other centres the proof leaves the exact line itself open. [Finite certificate and modulo-49 restrictions](https://github.com/lukeroyle-beep/Mathematics/blob/37bd10a930d6dc7c9a7bcfd8db7588451dc26da2/research/a398769/five-seven/settlement/README.md).

## Wider closed strips using the trillion-length certificate

For every reduced fraction \(0<a/b<1\) with \(b\le55\), every hypothetical full witness satisfies
\[
 |bi-aL|>\frac{L}{100000 b^2}.
\]
This includes the exact centre and both boundaries for every such fraction.

For \(L\le10^{12}\) use the complete valuation enumeration and the small decimal checks. For greater lengths suppose the inequality fails. Equation (2) of the merged analytic record gives
\[
 H\le |bi-aL|/b+b+1\le L/(100000 b^3)+b+1.
\]
Replace the height parameter by \(H'=L/(51000b^3)\). This enlargement is valid since it requires only
\[
 L\ge \frac{5100000}{49}b^3(b+1)\le\frac{6788100000000}{7}<10^{12}.
\]
For \(q=\lfloor L/b\rfloor\), \(q/H'+1\le1+51000b^2\le154275001<(27/10)^{19}<e^{19}\). As \(\log 7<\log 10\), the logarithmic entry in (13) is less than \(19.4\). Hence the maximum there is 20. The audited elimination of dependent roots and bound \(d<(L-2)/2\) apply at every hypothetical full witness in this range. We obtain
\[
 t\le d+63b^3 H'\,20^2
   <(L-2)/2+(42/85)L
   =169L/170-1<L-2 .
\]
This contradicts the valuation required at a full witness. The finite part and the analytic part meet with no gap. The strips still leave possible position ratios between them.
