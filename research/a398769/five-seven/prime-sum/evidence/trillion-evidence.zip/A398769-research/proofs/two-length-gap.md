## An effective gap between two lengths

For integers \(3\le i<L\), put \(F(L,i)=7\cdot10^L-18\cdot10^i-25\). The following argument applies to every such position. It uses neither the oddness of \(L\) nor divisibility by the digit sum.

**Pairwise valuation theorem.** Let \(m<M\), with positions \(i<m\) and \(j<M\) as above, and put \(v=\min(v_7(F(m,i)),v_7(F(M,j)))\). Then
\[
25\cdot7^{3v}<10^{2M}. \tag{1}
\]

**Proof.** Write \(p=7^v\), \(h=M-m\), and \(X=10^M/p\). Each \(F\) is positive and less than \(7\cdot10^L\), since \(i<L\). Each is divisible by 225, since \(10^r\equiv100\pmod{225}\) for every \(r\ge2\). Thus both values are divisible by \(225p\). In particular,
\[
10^h<\frac{7}{225}X. \tag{2}
\]
Let \(a=\min(i,j)\) and \(b=\min(m-i,M-j)\). We first bound both \(10^a\) and \(10^b\).

The difference \(D=F(M,j)-F(m,i)\) is positive, since
\[
D\ge7(10^M-10^{M-1})-18\cdot10^{M-1}>0.
\]
It is less than \(7\cdot10^M\). Both terms in \(D=7(10^M-10^m)-18(10^j-10^i)\) are divisible by \(10^a\), and the quotient remains a multiple of \(9p\). Consequently
\[
10^a<\frac79 X. \tag{3}
\]
The difference \(E=F(M,j)-10^h F(m,i)\) equals
\[
18(10^{h+i}-10^j)+25(10^h-1).
\]
It is 5 modulo 10 and is divisible by \(225p\). Since \(M-b=\max(h+i,j)\) and \(i\ge3\), its absolute value is less than \(19\cdot10^{M-b}\). Hence
\[
10^b<\frac{19}{225}X. \tag{4}
\]

Choose one point attaining \(a\), with length \(L_s\), and one attaining \(b\), with length \(L_t\). These choices may coincide. Put \(A=18\cdot10^a+25\) and \(B=7\cdot10^b-18\). The original equations give
\[
A\equiv7\cdot10^{L_s},\qquad B\,10^{L_t-b}\equiv25\pmod p.
\]
All powers of ten are invertible modulo \(p\). Also \(0<A<19\cdot10^a\), \(0<B<7\cdot10^b\).

If \(L_t\ge L_s\), take \(d=L_t-L_s\), \(e=\min(d,b)\), and
\[
R=10^{d-e}AB-175\cdot10^{b-e}.
\]
If \(L_t<L_s\), take \(d=L_s-L_t\) and
\[
R=AB-175\cdot10^{b+d}.
\]
In each case the two displayed congruences imply \(p\mid R\). Each term is divisible by 25, and the terms agree modulo 9 because \(10\equiv1\pmod9\), \(A\equiv25\pmod9\) and \(B\equiv7\pmod9\). Thus \(225p\mid R\).

In the first case \(R>0\). Indeed, \(B/10^b\ge7-18/10>5\) and \(A>35\). Its positive term is less than \(133\cdot10^a\max(10^b,10^d)\). Since \(d\le h\), (2)–(4) bound this by
\[
\frac{133\cdot7\cdot19}{9\cdot225}X^2=\frac{17689}{2025}X^2<9X^2.
\]
In the second case \(R\ne0\), since \(v_5(AB)=2\) and \(v_5(175\cdot10^{b+d})=2+b+d\). The first term satisfies the same upper bound \((17689/2025)X^2\); the second is less than \((175\cdot19\cdot7/225^2)X^2<9X^2\) by (2) and (4). Thus \(225p\le |R|<9X^2\) in both cases. Substituting \(X=10^M/p\) gives (1). ∎

**Consequences.** If both points reach the necessary witness depth at their own lengths, then \(v\ge m-2\). It follows that
\[
M>\tfrac32\log_{10}(7)m-3\log_{10}(7)+\log_{10}(5).
\]
The slope is approximately 1.2676470600 and the constant term is approximately \(-1.8363241157\). In particular, \(M>5m/4\) for \(m\ge105\). The exact integer inequalities \(625\cdot7^{6(105-2)}>10^{5\cdot105}\) and \(7^6>10^5\) establish this for all \(m\ge105\) by induction. A real interval \([Y,5Y/4]\) with \(Y\ge105\) therefore contains at most one length reaching the required depth. More generally, among all lengths at most \(N\), at most one length can attain a position satisfying \(25\cdot7^{3v_7(F)}\ge10^{2N}\).

At one fixed length \(L\ge5\), at most one position can reach \(L-2\). If two did, their difference would give \(7^{L-2}\mid 10^{|i-j|}-1\). The order of 10 modulo \(7^k\) is \(6\cdot7^{k-1}\). This follows from the order 6 modulo 7, \(v_7(10^6-1)=1\), and the lifting-the-exponent formula. Thus \(6\cdot7^{L-3}\mid |i-j|\), impossible since \(0<|i-j|<L\).

**Finite control.** We checked every distinct-length pair from odd lengths 5 through 83 and positions \(3\le i<L\) congruent to 3 modulo 6. Among 39,858 pairs, the minimum-position and minimum-gap indices were the same in 16,198 cases, the minimum-gap index came later in 12,467 cases, and it came earlier in 11,193 cases. In each case the appropriate residual was nonzero, divisible by \(225\cdot7^v\), and (1) held. These checks verify the three algebraic cases on small inputs. The proof supplies their unbounded scope.
