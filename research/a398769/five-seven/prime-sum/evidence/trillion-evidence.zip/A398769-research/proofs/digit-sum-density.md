# The digit-sum congruence fails for almost every length

Let \(S_L=7L-4\) and \(F(L,i)=7\cdot10^L-18\cdot10^i-25\). The set
\[
\mathcal D=\{L\ge1:\ S_L\mid F(L,i)\text{ for some integer }i\ge0\}
\]
has natural density zero, also relative to every fixed arithmetic progression of positive lengths. The exponent in this statement need not be a valid digit position. In particular, for almost every odd length the digit-sum congruence alone excludes every position. The [project's fixed-depth theorem](https://github.com/lukeroyle-beep/Mathematics/blob/37bd10a930d6dc7c9a7bcfd8db7588451dc26da2/research/a398769/five-seven/fixed-depth/README.md) gives infinitely many lengths passing even the stronger digit-sum test at actual positions. The conclusion here is compatible with those exceptions.

## A local obstruction

Take a prime \(p\equiv1\pmod {40}\), and write \(\chi_p\) for the quadratic character of the field with \(p\) elements, with \(\chi_p(0)=0\). Both 2 and 5 are quadratic residues modulo \(p\), by quadratic reciprocity and the supplementary law for 2. Thus \(18\cdot10^i\) is a nonzero square for every \(i\ge0\). The conditions
\[
 E_p(L):\quad p\mid S_L,\qquad \chi_p(7\cdot10^L-25)=-1
\]
exclude \(L\) from \(\mathcal D\). If \(d_p\) is the multiplicative order of 10 modulo \(p\), this event is periodic in \(L\) modulo \(p d_p\).

## One prime inside a fixed progression

Fix a positive integer \(M\). Among primes in the class \(1\pmod{40}\), all but a set having relative natural density zero among the primes satisfy
\[
  p\nmid M,\qquad d_p\ge 20M\sqrt p .
\]
Indeed, apply the unconditional order theorem to the base 10 and the function \(\epsilon(x)=\log(20M)/\log x\) for \(x>1\). It yields \(d_p\ge p^{1/2+\epsilon(p)}\) outside a set of \(o(x/\log x)\) primes up to \(x\). The prime number theorem in arithmetic progressions then gives the desired good primes counting function asymptotic to \(x/(16\log x)\). Their reciprocal sum diverges by partial summation. Only this divergence for each fixed \(M\) is used below. [Erdős and Murty, *On the order of a (mod p)*, Theorem 1, pp. 87–97](https://doi.org/10.1090/crmp/019/10). [Akbary and Yazdani, Lemma 2.3(i), explicit statement for general integer bases](https://www.cs.uleth.ca/~akbary/Akbary-Yazdani.pdf).

For each such prime and every \(r\bmod M\), the relative frequency of \(p\mid S_L\) in the progression \(L\equiv r\pmod M\) equals \(1/p\). After imposing that additional congruence, \(L\) varies by steps of \(Mp\). Since \(d_p\mid p-1\), its residues modulo \(d_p\) visit one coset of the multiples of \(\gcd(M,d_p)\), each equally frequently. Consequently \(10^L\pmod p\) is uniform on a multiplicative coset \(C=uH\) of size
\[
 h=\frac{d_p}{\gcd(M,d_p)}\ge20\sqrt p .
\]

For any such coset,
\[
 \left|\sum_{z\in C}\chi_p(7z-25)\right|\le\sqrt p .
\]
To see this, put \(k=(p-1)/h\). On nonzero field elements the indicator of \(C\) equals the average of \(\psi(z/u)\) over the \(k\) multiplicative characters \(\psi\) trivial on \(H\). For each character, substitute \(z=(25/7)y\). Up to a scalar of absolute value one the resulting sum is \(J(\psi,\chi_p)=\sum_y\psi(y)\chi_p(1-y)\), with every multiplicative character extended by zero at zero. Its modulus is \(\sqrt p\) when \(\psi\) and \(\psi\chi_p\) are both nontrivial, and 1 in the two remaining cases. Taking the average proves the bound. [Conrad, *Gauss and Jacobi sums on finite fields and Z/mZ*, Corollary 2.5 and Theorem 2.6](https://kconrad.math.uconn.edu/blurbs/gradnumthy/Gauss-Jacobi-sums.pdf).

There is at most one \(z\in C\) for which \(7z-25=0\). Thus at least \((h-1-\sqrt p)/2\ge h/3\) elements of the coset give a negative character. Denoting relative frequency in the progression by \(\mathbb P_r\), we have
\[
     1/(3p)\le\mathbb P_r(E_p)\le1/p .
\]

## A finite group of primes and iteration

Choose a finite set \(B\) of good primes with \(s=\sum_{p\in B}1/p\ge1\). Use the uniform distribution over those residues modulo \(M'=\operatorname{lcm}(M,\{p d_p:p\in B\})\) that equal \(r\bmod M\). For distinct \(p,q\in B\), the Chinese remainder theorem gives
\[
 \mathbb P_r(E_p\cap E_q)\le\mathbb P_r(pq\mid7L-4)=1/(pq).
\]
This comparison only uses divisibility by \(p,q\), so shared factors among their exponent periods do not affect it.

For \(Z=\sum_{p\in B}\mathbf1_{E_p}\), we obtain \(\mathbb E_r Z\ge s/3\) and \(\mathbb E_r Z^2\le s+s^2\). Cauchy–Schwarz applied to \(Z\mathbf1_{Z>0}\) now gives
\[
 \mathbb P_r(Z>0)\ge
 \frac{(\mathbb E_r Z)^2}{\mathbb E_r Z^2}
 \ge\frac{s}{9(1+s)}\ge\frac1{18}.
\]
The same finite set \(B\) works for every residue \(r\bmod M\).

Start in any fixed progression, including all positive integers with \(M=1\). After one stage, the surviving lengths form a finite union of residue classes modulo \(M'\). Repeat with \(M'\) as the fixed modulus. After \(j\) stages the upper density of \(\mathcal D\), relative to the initial progression, is bounded by \((17/18)^j\). Sending \(j\) to infinity proves the theorem.

For every positive tolerance the proof gives a finite, in-principle computable union of certified periodic exclusions of relative density exceeding one minus that tolerance. Good primes can be recognized by finite integer arithmetic, and divergence guarantees termination of each finite prime selection. The theorem supplies neither a final witness cutoff nor an exclusion of the exceptional lengths.
