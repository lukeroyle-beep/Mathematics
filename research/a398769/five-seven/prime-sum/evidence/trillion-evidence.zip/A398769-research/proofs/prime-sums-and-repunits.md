## An all-length obstruction for prime digit sums

Suppose the digit sum \(S=7L-4\) is a prime \(p\), with \(L\) in the reduced domain (odd, \(L\ge5\)). Then \(p\ge31\) and \(p\equiv3\pmod7\). The following explicit test excludes a set of primes of relative natural density exactly \(2/3\) among primes in that progression. A failed test excludes every position at the associated length. A passing test leaves the length undecided.

Write \(x=10^L\bmod p\), put \(w=(7x-25)/18000\bmod p\), and let \(g=\gcd(6,p-1)\). A witness requires

\[
w\ne0,\qquad w^{(p-1)/g}=1\pmod p.
\]

Indeed, modulo seven the equation \(F=7\cdot10^L-18\cdot10^i-25\equiv0\) forces \(3^i=-1\pmod7\), so \(i=3+6k\). Modulo \(p\), the digit-sum condition gives \(w=(10^k)^6\), which proves the test by cyclicity of the multiplicative group of the prime field. The reduction uses \(p\mid F\), a necessary consequence of the full divisor. In this prime-sum domain, \(9\mid F\) identically and \(p\ne3\), so \(p\mid F\) is equivalent to the full digit-sum test \(9p\mid F\) for a specified \(i\). The sixth-power condition still leaves the requirement that the root must be a suitable bounded power of ten. Fermat's theorem gives \(x^7=10^{p+4}=10^5\pmod p\), and \(p\equiv3\pmod7\) makes \(x\) the unique seventh root of \(10^5\) in this field.

### Proof of the density

Let \(K\) be the splitting field of \(X^7-10^5\) with a primitive sixth root of unity adjoined. Denote its seven roots by \(x_j=\zeta_7^j x_0\), indexed by the integers modulo seven, and write \(w_j=(7x_j-25)/18000\). The seven roots are conjugate. Indeed, with \(t=10^{1/7}\), we have \(x_0=t^5\) and \(t=x_0^3/100\), and \(X^7-10\) is Eisenstein at two.

The prime 211 is unramified in \(K\). It divides neither the discriminant of \(X^7-10^5\) nor that of the sixth cyclotomic field. Also

\[
\prod_j(7x_j-25)=7^7\,10^5-25^7=76{,}250{,}784{,}375=3^3\,5^5\,211\,4283.
\]

At any prime ideal of \(K\) above 211 the valuations of all seven numerators are nonnegative and their sum is one. Exactly one numerator has valuation one. The denominator 18000 is a unit there. Conjugating the prime ideal exhibits, for each \(j\), a valuation that is one on \(w_j\) and zero on the other six. Thus, whenever \(\prod_jw_j^{e_j}\) is a sixth power in \(K\), each \(e_j\) is divisible by six. Kummer theory shows that adjoining all seven sixth roots gives a Galois extension \(E/K\) with group \( (\mathbf Z/6\mathbf Z)^7\), acting by independent multiplication by sixth roots of unity. The extension \(E/\mathbf Q\) is Galois because conjugation permutes the \(w_j\) and \(K\) contains all sixth roots of unity. [Milne, *Fields and Galois Theory*, Theorem 5.28](https://www.jmilne.org/math/CourseNotes/FT421.pdf)

For an unramified prime \(p\equiv3\pmod7\), its Frobenius element on the \(x_j\) acts by \(j\mapsto3j+b\). This permutation has exactly one fixed root. At that root, label its six sixth roots by exponents \(a\) of a primitive sixth root of unity. The lifts of a fixed Frobenius element from \(K\) to \(E\) act by \(a\mapsto pa+h\), with the six shifts \(h\) appearing equally often. A fixed sixth root exists precisely when \(g\mid h\). Its proportion among lifts is therefore \(1/g\). A fixed sixth root at another \(x_j\) is impossible since its sixth power determines \(x_j\). Outside the finitely many primes dividing \(2\cdot3\cdot5\cdot7\cdot211\cdot4283\), all the radicands are nonzero units and the polynomials give distinct roots after reduction. The fixed-root condition is then equivalent to the finite-field sixth-power test. This finite exception set includes \(p=3\), already outside the permitted lengths. Individual admissible primes in the exception set can still be tested by the explicit modular criterion.

There are two invertible residue classes modulo 42 above \(3\bmod7\), namely 17 and 31. They occur equally often. In class 17, \(g=2\), and in class 31, \(g=6\). Chebotarev's density theorem counts the Frobenius elements in each group fibre, giving relative passing density \( (1/2+1/6)/2=1/3\). The rejection density is \(2/3\) in the prime-sum progression, or \(1/9\) among all rational primes. These fractions describe this necessary test alone. [Lenstra, *The Chebotarev Density Theorem*](https://websites.math.leidenuniv.nl/algebra/Lenstra-Chebotarev.pdf)

### Exact controls

| Prime \(p\) | Length \(L\) | \(x\) | \(w\) | \(g\) | \(w^{(p-1)/g}\bmod p\) |
|---:|---:|---:|---:|---:|---:|
| 31 | 5 | 25 | 23 | 6 | 30 |
| 59 | 9 | 32 | 28 | 2 | 1 |
| 73 | 11 | 51 | 67 | 6 | 8 |
| 70,000,157 | 10,000,023 | 35,539,095 | 67,991,751 | 2 | 70,000,156 |

The first and last rows reject at every position, the second passes this necessary test, and the third illustrates rejection by the sixth-power test even though \(w\) is a square. The prime in the last row can be checked by trial division through 8,366.

## An all-length obstruction for composite digit sums

For any \(m\ge3\), put \(R_m=(10^m-1)/9\). If \(R_m\mid S\), every position at that length fails \(9S\mid F\). To see this, set \(Q=10^m-1\), \(a=L\bmod m\), \(b=i\bmod m\). If the digit-sum condition held, \(Q\) would divide

\[
G=7\,10^a-18\,10^b-25.
\]

Since \(0\le a,b<m\), we have \(G\le7\,10^{m-1}-43<Q\) and \(G\ge-18\,10^{m-1}-18>-2Q\). Hence \(G\) could only be \(0\) or \(-Q\). The possible residues of \(G\) modulo five are \(0,2,4\), whereas \(-Q\equiv1\pmod5\). Residue zero requires \(a,b>0\), in which case \(G\equiv5\pmod{10}\). Both possibilities are therefore excluded.

For example, \(R_{19}=1{,}111{,}111{,}111{,}111{,}111{,}111\equiv1\pmod7\). Taking \(S=(3+14t)R_{19}\) excludes every position at every odd length

\[
L=476{,}190{,}476{,}190{,}476{,}191+2{,}222{,}222{,}222{,}222{,}222{,}222\,t,\qquad t\ge0.
\]

These obstructions give infinitely many distinct progressions even after excluding sums divisible by five. For each prime index \(m\ge5\), \(R_m\) is coprime to \(3\cdot5\cdot7\) and to \(R_q\) for every different prime index \(q\). The last assertion follows from \(\gcd(R_m,R_q)=R_{\gcd(m,q)}\). Since \(m\equiv1\) or \(5\pmod6\), respectively \(R_m\equiv1\) or \(2\pmod7\). Taking \(S=3R_m\) or \(S=3^5R_m\), respectively, gives a five-free admissible example of the corresponding progression lying in no other prime-index progression with index at least five. Each prime in any fixed finite sieve of forbidden sum divisors other than three can divide at most one of these \(R_m\). In contrast, the repunit-divisor criterion by itself has no prime-sum instances, since \(S=R_m\) would force \(10^m=9S+1=7(9L-5)\).

As a small check, \(m=5\), \(L=30{,}159\), \(S=211{,}109=19R_5\) gives a nonzero remainder \(F\bmod9S\) at every \(3\le i<L\) by direct modular enumeration. As a positive control, \(L=61,i=57,S=423\) gives \(F\bmod9S=0\) and \(F\bmod49=35\).
